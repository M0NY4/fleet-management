import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Users, ChevronRight, IndianRupee, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";

export function TripCard({ trip, onClick }) {
  const seatsPercent = Math.round(((trip.totalSeats - trip.seatsRemaining) / (trip.totalSeats || 1)) * 100);
  const routePoints = trip.routePoints || [];
  const pickup = routePoints[0] || "TBD";
  const drop = routePoints[routePoints.length - 1] || "TBD";
  
  const formatDate = (dateStr) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const formatTime = (dateStr) => {
    const d = new Date(dateStr);
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  };

  const totalExpenses = (trip.tripExpences || []).reduce((sum, exp) => sum + exp.ammountRs, 0);
  const revenue = trip.distanceKm * trip.ratePerKm;
  const profit = revenue - totalExpenses;

  return (
    <div 
      className="group relative bg-white border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer"
      onClick={() => onClick(trip)}
    >
      <div className={cn(
        "h-2 w-full",
        trip.status === "UPCOMING" ? "bg-blue-500" :
        trip.status === "ONGOING" ? "bg-amber-500 animate-pulse" :
        trip.status === "COMPLETED" ? "bg-emerald-500" : "bg-destructive"
      )} />
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-extrabold text-lg text-foreground group-hover:text-primary transition-colors">{trip.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] font-bold bg-muted px-2 py-0.5 rounded text-muted-foreground uppercase">ID: {trip.id}</span>
              <span className="text-[10px] font-bold bg-primary/5 text-primary px-2 py-0.5 rounded uppercase">{routePoints.length} Stops</span>
            </div>
          </div>
          <StatusBadge status={trip.status} />
        </div>

        {/* Visual Route Timeline */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1">
            <p className="text-[10px] uppercase font-bold text-muted-foreground mb-1">Origin</p>
            <p className="text-sm font-black truncate uppercase tracking-tight">{pickup}</p>
          </div>
          <div className="flex flex-col items-center gap-1 px-2 shrink-0">
             <div className="h-px w-8 bg-border border-t border-dashed" />
             <MapPin className="h-3.5 w-3.5 text-primary" />
             <div className="h-px w-8 bg-border border-t border-dashed" />
          </div>
          <div className="flex-1 text-right">
            <p className="text-[10px] uppercase font-bold text-muted-foreground mb-1">Destination</p>
            <p className="text-sm font-black truncate uppercase tracking-tight">{drop}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6 pt-4 border-t border-dashed">
          <div>
            <p className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Departure</p>
            <p className="text-sm font-bold">{formatDate(trip.startDate)}</p>
            <p className="text-[10px] font-medium text-muted-foreground">{formatTime(trip.startDate)}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1 justify-end"><Calendar className="h-3 w-3" /> Arrival</p>
            <p className="text-sm font-bold">{formatDate(trip.endDate)}</p>
            <p className="text-[10px] font-medium text-muted-foreground">{formatTime(trip.endDate)}</p>
          </div>
        </div>

        {/* Occupancy */}
        <div className="space-y-1.5 mb-6">
          <div className="flex justify-between text-[10px] font-black uppercase tracking-tight">
            <span className="text-muted-foreground">Seats Available</span>
            <span className={cn(trip.seatsRemaining < 5 ? "text-destructive" : "text-primary")}>{trip.seatsRemaining} / {trip.totalSeats} Free</span>
          </div>
          <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
            <div 
              className={cn("h-full rounded-full transition-all duration-500", trip.seatsRemaining < 5 ? "bg-destructive" : "bg-primary")}
              style={{ width: `${Math.max(0, 100 - seatsPercent)}%` }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex flex-col gap-4 pt-4 border-t border-border/40">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">Est. Revenue</p>
              <p className="text-lg font-black text-emerald-600 flex items-center tracking-tighter">
                <IndianRupee className="h-3.5 w-3.5 mr-0.5" />{revenue.toLocaleString()}
              </p>
            </div>
            <div className="flex flex-col text-right">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">Expenses</p>
              <p className="text-lg font-black text-destructive flex items-center justify-end tracking-tighter">
                <IndianRupee className="h-3.5 w-3.5 mr-0.5" />{totalExpenses.toLocaleString()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className={cn(
              "px-3 py-1.5 rounded-lg flex items-center gap-2",
              profit >= 0 ? "bg-emerald-50 text-emerald-700" : "bg-destructive/5 text-destructive"
            )}>
              <TrendingUp className="h-3.5 w-3.5" />
              <span className="text-xs font-black tracking-tight">
                ₹{profit.toLocaleString()} {profit >= 0 ? 'Profit' : 'Loss'}
              </span>
            </div>
            <Button variant="secondary" size="sm" className="rounded-lg font-bold group-hover:bg-primary group-hover:text-primary-foreground transition-all h-8 text-xs px-4">
              Details <ChevronRight className="h-3.5 w-3.5 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
