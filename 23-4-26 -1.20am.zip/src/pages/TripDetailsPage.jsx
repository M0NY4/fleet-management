import { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { PageLayout } from "@/components/layout/PageLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { getTrips, getCustomerBookings } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/DataTable";
import { TableContainer } from "@/components/layout/TableContainer";
import {
  ArrowLeft,
  MapPin,
  Calendar,
  Truck,
  IndianRupee,
  Users,
  Clock,
  ShieldCheck,
  Map as MapIcon,
  MoreVertical,
  Plus,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  History,
  Receipt,
  HardDrive,
  Wallet,
  Calculator,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

function ExpenseInput({ label, value, setter, icon: Icon }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">
        {label}
      </Label>
      <div className="relative group">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors">
          <Icon className="h-3.5 w-3.5" />
        </div>
        <Input
          type="number"
          value={value}
          onChange={(e) => setter(Number(e.target.value))}
          className="h-9 pl-9 border-border/60 bg-muted/20 focus-visible:ring-primary transition-all font-bold text-sm"
          placeholder="0.00"
        />
      </div>
    </div>
  );
}

function DetailItem({ label, value, icon: Icon, colorClass }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border/40">
      <div
        className={cn(
          "p-2 rounded-md",
          colorClass || "bg-primary/10 text-primary",
        )}
      >
        <Icon className="h-4 w-4" />
      </div>
      <div>
        <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
          {label}
        </p>
        <p className="text-sm font-bold text-foreground">{value}</p>
      </div>
    </div>
  );
}

export default function TripDetailsPage() {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [trips, setTrips] = useState([]);
  const [trip, setTrip] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getTrips().then((data) => {
      setTrips(data);
      const currentTrip = data.find((t) => String(t.id) === String(tripId));
      setTrip(currentTrip);
      setLoading(false);
    });
  }, [tripId]);

  if (loading) {
    return (
      <DashboardLayout>
        <PageLayout>
           <div className="h-96 flex flex-col items-center justify-center gap-4">
              <div className="h-10 w-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Fetching Trip Dossier...</p>
           </div>
        </PageLayout>
      </DashboardLayout>
    );
  }

  if (!trip) {
    return (
      <DashboardLayout>
        <PageLayout>
          <div className="flex flex-col items-center justify-center py-24 bg-card border rounded-2xl border-dashed">
            <AlertCircle className="h-12 w-12 text-muted-foreground/30 mb-4" />
            <h2 className="text-xl font-bold">Trip not found</h2>
            <p className="text-muted-foreground text-sm mt-1">
              The trip ID you requested does not exist or has been archived.
            </p>
            <Button
              variant="primary"
              className="mt-6 font-bold"
              onClick={() => navigate("/trips")}
            >
              Back to Fleet Ops
            </Button>
          </div>
        </PageLayout>
      </DashboardLayout>
    );
  }

  const totalExpenses = (trip.tripExpences || []).reduce((sum, exp) => sum + exp.ammountRs, 0);
  const totalRevenue = (trip.distanceKm || 0) * (trip.ratePerKm || 0);
  const occupancyPercent = Math.round(((trip.totalSeats - trip.seatsRemaining) / (trip.totalSeats || 1)) * 100);
  const profit = totalRevenue - totalExpenses;

  const expenseCols = [
    { header: "Expense Name", accessor: "name" },
    { 
      header: "Amount", 
      accessor: (r) => <span className="font-bold text-destructive">₹{(r.ammountRs || 0).toLocaleString()}</span> 
    },
    { 
      header: "Receipt", 
      accessor: (r) => r.documentPath ? <Button variant="link" size="sm" className="h-auto p-0 font-bold">View Doc</Button> : <span className="text-[10px] text-muted-foreground uppercase font-bold">No Doc</span> 
    },
  ];

  return (
    <DashboardLayout>
      <PageLayout fullWidth>
        {/* Top Operational Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-primary text-primary-foreground p-6 rounded-2xl shadow-lg relative overflow-hidden">
          <Truck className="absolute -right-10 -bottom-10 h-64 w-64 text-white/5 pointer-events-none rotate-12" />

          <div className="flex items-center gap-4 relative z-10">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate("/trips")}
              className="rounded-full bg-white/10 border-white/20 hover:bg-white/20 text-white"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-black tracking-tight">
                  {trip.name}
                </h1>
                <StatusBadge status={trip.status} />
              </div>
              <p className="text-white/70 text-sm font-medium mt-1">
                Trip ID: <span className="text-white font-bold">#{trip.id}</span> • 
                Last Modified: <span className="text-white font-bold">{new Date(trip.lastModifiedAt).toLocaleDateString()}</span>
              </p>
            </div>
          </div>

          <div className="flex gap-2 relative z-10">
            <Button variant="secondary" className="font-bold shadow-sm" onClick={() => toast.info("Exporting dossier...")}>Dossier</Button>
            <Button className="bg-accent text-accent-foreground font-black hover:bg-accent/90" onClick={() => toast.success("Live tracking active")}>Live Track</Button>
          </div>
        </div>

        {/* Top Logistical Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <DetailItem
                label="Departure"
                value={new Date(trip.startDate).toLocaleString()}
                icon={Calendar}
                colorClass="bg-blue-500/10 text-blue-600"
              />
              <DetailItem
                label="Arrival"
                value={new Date(trip.endDate).toLocaleString()}
                icon={Calendar}
                colorClass="bg-orange-500/10 text-orange-600"
              />
              <DetailItem
                label="Total Distance"
                value={`${trip.distanceKm} KM`}
                icon={MapPin}
                colorClass="bg-indigo-500/10 text-indigo-600"
              />
              <DetailItem
                label="Commercial Rate"
                value={`₹${trip.ratePerKm} / KM`}
                icon={IndianRupee}
                colorClass="bg-emerald-500/10 text-emerald-600"
              />
            </div>

            <Card className="border-border/40 overflow-hidden shadow-sm">
              <CardHeader className="bg-muted/30 border-b pb-4">
                <CardTitle className="text-base flex items-center gap-2">
                  <MapIcon className="h-4 w-4 text-primary" /> Route Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 px-10 max-h-[400px] overflow-y-auto">
                <div className="relative border-l-2 border-primary/20 pl-8 space-y-12 my-4">
                  {(trip.routePoints || []).map((point, index) => (
                    <div key={index} className="relative">
                      <div className={cn(
                        "absolute -left-[41px] top-0 h-5 w-5 rounded-full border-4 border-background shadow-sm",
                        index === 0 ? "bg-primary animate-pulse" : 
                        index === (trip.routePoints || []).length - 1 ? "bg-emerald-500" : "bg-muted-foreground/30"
                      )} />
                      <div className="flex flex-col">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
                          {index === 0 ? "Origin / Start" : index === trip.routePoints.length - 1 ? "Final Destination" : `Waypoint ${index}`}
                        </span>
                        <span className="text-lg font-black text-foreground uppercase tracking-tight">
                          {point}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-indigo-500/20 bg-indigo-50/10 shadow-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center justify-between text-indigo-900/70">
                  Operational Health
                  <ShieldCheck className="h-4 w-4 text-emerald-500" />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-[10px] font-black uppercase mb-1.5 tracking-tight">
                    <span className="text-muted-foreground">Load Factor</span>
                    <span className={cn(occupancyPercent > 90 ? "text-destructive" : "text-indigo-600")}>
                      {trip.totalSeats - trip.seatsRemaining} / {trip.totalSeats} Seats Filled
                    </span>
                  </div>
                  <div className="h-2 w-full bg-indigo-100/50 rounded-full overflow-hidden border border-indigo-200/20">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-1000",
                        occupancyPercent > 90 ? "bg-destructive" : "bg-indigo-600"
                      )}
                      style={{ width: `${occupancyPercent}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-xl bg-white border border-indigo-100 shadow-sm">
                  <div className="h-10 w-10 rounded-full bg-emerald-50 flex items-center justify-center border border-emerald-100">
                    <TrendingUp className={cn("h-5 w-5", profit >= 0 ? "text-emerald-600" : "text-destructive")} />
                  </div>
                  <div className="flex flex-col">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                      Profitability
                    </p>
                    <p className={cn("text-xl font-black tracking-tighter", profit >= 0 ? "text-emerald-700" : "text-destructive")}>
                      ₹{profit.toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground pl-1">Operational Controls</h3>
              <Button className="w-full h-12 rounded-xl font-black uppercase tracking-wider bg-foreground text-background">Archive Records</Button>
              <Button variant="outline" className="w-full h-12 rounded-xl font-bold border-2 border-primary/20 text-primary">Modify Route</Button>
              <Button variant="ghost" className="w-full h-12 rounded-xl font-bold text-destructive">Abort Operation</Button>
            </div>
          </div>
        </div>

        {/* Expenses Ledger */}
        <div className="space-y-4 mt-8">
           <div className="flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Receipt className="h-4 w-4 text-primary" /> Expenditure Dossier
              </h3>
              <Button variant="outline" size="sm" className="h-8 font-bold border-dashed border-2" onClick={() => toast.info("Add expense coming soon")}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Log Expense
              </Button>
           </div>
           <TableContainer>
              <DataTable columns={expenseCols} data={trip.tripExpences || []} />
           </TableContainer>
        </div>

        {/* Financial Summary */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
           <Card className="bg-white border-none shadow-sm p-6">
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Gross Revenue</p>
              <p className="text-2xl font-black text-foreground">₹{totalRevenue.toLocaleString()}</p>
              <p className="text-[10px] text-muted-foreground mt-2 font-bold uppercase tracking-tight">{trip.distanceKm}KM × ₹{trip.ratePerKm}</p>
           </Card>
           <Card className="bg-white border-none shadow-sm p-6">
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Total Expenditure</p>
              <p className="text-2xl font-black text-destructive">₹{totalExpenses.toLocaleString()}</p>
              <p className="text-[10px] text-muted-foreground mt-2 font-bold uppercase tracking-tight">{(trip.tripExpences || []).length} Line items</p>
           </Card>
           <Card className={cn("border-none shadow-md p-6", profit >= 0 ? "bg-emerald-500 text-white" : "bg-destructive text-white")}>
              <p className="text-[10px] font-black uppercase tracking-widest text-white/70 mb-1">Net Operational Profit</p>
              <p className="text-3xl font-black">₹{profit.toLocaleString()}</p>
              <div className="flex items-center gap-2 mt-2">
                 <TrendingUp className="h-4 w-4" />
                 <span className="text-[10px] font-black uppercase tracking-widest">{Math.round((profit/totalRevenue)*100)}% Margin</span>
              </div>
           </Card>
        </div>
      </PageLayout>
    </DashboardLayout>
  );
}

